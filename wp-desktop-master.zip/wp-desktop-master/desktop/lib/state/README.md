State
==========

Provides user state functions, initially for logged in state, but easily
extended to other cases at they rise

