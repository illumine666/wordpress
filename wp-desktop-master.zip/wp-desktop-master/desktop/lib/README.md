Desktop App Libraries
=====================

The following libraries are available:

- [App Instance](app-instance/README.md)
- [App Quit](app-quit/README.md)
- [Config](config/README.md)
- [Cookie Auth](cookie-auth/README.md)
- [Crash Tracker](crash-tracker/README.md)
- [Debug Tools](debug-tools/README.md)
- [IPC](ipc/README.md)
- [Log](log/README.md)
- [Menu](menu/README.md)
- [Menu Setter](menu-setter/README.md)
- [Platform](platform/README.md)
- [Settings](settings/README.md)
- [Window Manager](window-manager/README.md)
