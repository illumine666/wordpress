App Quit
=========

Determines whether the app should quit and exit, or quit to background.

Note that the implementation of quit-to-background is left up to `lib/platform`.
