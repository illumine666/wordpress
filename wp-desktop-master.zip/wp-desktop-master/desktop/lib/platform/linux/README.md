Linux Platform
==========

Provides any Linux specific platform features.


## Closing & Quitting

The app will quit when close, Mac and Windows is minimized.

