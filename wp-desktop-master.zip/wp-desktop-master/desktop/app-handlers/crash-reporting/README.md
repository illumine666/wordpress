Crash Reporting
=========

Uses the [Electron crash reporter module](https://github.com/atom/electron/blob/master/docs/api/crash-reporter.md) to send crashes to a remote URL.

# Config

Requires `crash_reporter` to be set
