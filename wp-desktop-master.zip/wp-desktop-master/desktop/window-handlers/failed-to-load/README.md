Failed to load
=========

A general catch-all for Chrome errors. If something goes wrong loading a page then show an error page.
