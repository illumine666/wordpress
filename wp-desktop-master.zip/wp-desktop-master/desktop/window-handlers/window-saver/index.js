'use strict';

/**
 * External Dependencies
 */
const debounce = require( 'lodash.debounce' );

/**
 * Internal dependencies
 */
const Settings = require( 'lib/settings' );

/**
 * Module variables
 */
const SAVE_SETTINGS_DELAY = 1000;

module.exports = function( mainWindow ) {
	const settingSaver = debounce( function() {
		Settings.saveSetting( 'window', mainWindow.getBounds() );
	}, SAVE_SETTINGS_DELAY );

	mainWindow.on( 'resize', function() {
		settingSaver();
	} );

	mainWindow.on( 'move', function() {
		settingSaver();
	} );
};
