Notifications
=========

Handles the notification badge.

## IPC messages

Listens for the following:

- `unread-notices-count` - sent by Calypso when a the unread notifications count changes
- `preferences-changed-notification-badge` - sent when the notification badge preference is changed
