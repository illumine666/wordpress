Login Status
=========

Toggles menu items that require the user to be logged in.

## IPC messages

Listens for the following:

- `user-login-status` - sent by Calypso when a user login status changes
