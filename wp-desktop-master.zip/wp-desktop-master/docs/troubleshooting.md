# Troubleshooting

* The WordPress icon will only show in the release version. The dev version will use the Electron icon
* If you see issue, try deleting `node_modules` and `npm install`
* Electron is more or less Chrome, you can get developer tools using `CMD+ALT+I`
* strict mode is used in desktop app files for compatibility with the version of Node used by Electron
